# Design System Document

## 1. Overview & Creative North Star
### The Industrial Architect
This design system moves away from the "standard utility" look and toward a high-end, editorialized industrial experience. The **Creative North Star** is "The Industrial Architect"—a vision where heavy-duty industrial logistics meets the precision and airy sophistication of a premium architectural firm. 

We break the "template" aesthetic by utilizing **intentional asymmetry** (e.g., staggering card layouts), high-contrast typography scales, and a departure from traditional borders. The interface should feel as sturdy as a shipping container but as refined as a gallery catalog. We prioritize breathing room over information density, ensuring that every industrial action feels deliberate and premium.

---

## 2. Colors
Our palette is anchored in a neutral, high-end industrial base with a singular, high-vibrancy kinetic orange for action.

*   **Primary Kinetic:** `primary` (#a04100) and `primary_container` (#ff6b00). This orange is used exclusively for movement and conversion.
*   **Deep Structural:** `on_background` (#1a1c1c) and `secondary` (#5d5e61). These shades provide the "slate" weight for typography.
*   **Surface Tiers:** A series of cool grays from `surface_container_lowest` (#ffffff) to `surface_dim` (#dadada).

### The "No-Line" Rule
**Explicit Instruction:** Prohibit the use of 1px solid borders for sectioning. Structural boundaries must be defined solely through background color shifts or tonal nesting.
*   *Example:* A `surface_container_low` section sitting directly on a `surface` background provides all the separation required.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of materials. Use the `surface_container` tiers to create depth:
1.  **Base:** `background` (#f9f9f9)
2.  **Sectioning:** `surface_container_low` (#f3f3f3)
3.  **Actionable Cards:** `surface_container_lowest` (#ffffff)

### Signature Textures
To add "soul," use subtle linear gradients on primary CTAs moving from `primary` (#a04100) to `primary_container` (#ff6b00) at a 135-degree angle. This prevents the orange from looking "flat" or "cheap" and adds a metallic, industrial sheen.

---

## 3. Typography
The typography strategy pairs the structural stability of **Work Sans** with the functional clarity of **Inter**.

*   **Display & Headlines (Work Sans):** Used for large-scale editorial moments. The wider tracking and geometric forms convey authority. Use `display-lg` for hero headlines to establish an immediate "Architectural" feel.
*   **Titles & Body (Inter):** Reserved for technical data and labels. Inter’s tall x-height ensures readability in complex industrial configurations (e.g., box dimensions).
*   **Hierarchy as Identity:** By using a massive scale jump between `headline-lg` (2rem) and `body-md` (0.875rem), we create a high-end editorial rhythm that guides the user’s eye through the industrial workflow without clutter.

---

## 4. Elevation & Depth
Elevation is achieved through **Tonal Layering** rather than artificial dropshadows.

*   **The Layering Principle:** Place a `surface_container_lowest` (White) card on a `surface_container_low` (Light Gray) background. This creates a "soft lift" that feels architectural.
*   **Ambient Shadows:** For floating elements (Modals, Hovered Cards), use ultra-diffused shadows: `box-shadow: 0 12px 40px rgba(22, 24, 26, 0.05)`. The shadow must be tinted with the `on_surface` color to look natural.
*   **The Ghost Border:** If a boundary is required for accessibility, use `outline_variant` at **15% opacity**. 100% opaque borders are strictly forbidden.
*   **Glassmorphism:** For top navigation or floating toolbars, use `surface_container_lowest` at 80% opacity with a `backdrop-blur: 12px`. This integrates the UI components into the environment.

---

## 5. Components

### Buttons
*   **Primary:** `primary_container` (#ff6b00) background, `on_primary` (#ffffff) text. Use `lg` (1rem) roundedness. No border.
*   **Secondary:** `surface_container_high` (#e8e8e8) background. This provides a tactile "recessed" look.
*   **Tertiary:** Transparent background with `primary` text. No box, just typography.

### Input Fields
*   **Style:** Large, high-affordance fields using `surface_container_lowest`.
*   **Interaction:** On focus, transition the background to `surface_bright` and apply a "Ghost Border" of `primary_container` at 30% opacity. 
*   **Labels:** Use `label-md` in `secondary` (#5d5e61) placed outside the input for maximum legibility.

### Industrial Cards
*   **Style:** Card-based layout with `md` (0.75rem) rounded corners.
*   **Constraint:** Forbid divider lines. Use `spacing.8` (2rem) of vertical white space to separate card content sections. Use a `surface_container_low` background for internal card footers to create a "nested" depth.

### Box Type Selection (Chips)
*   **Style:** Large, square-format selection chips. Instead of a checkbox, use a `primary` color "Ghost Border" and a subtle background shift to `primary_fixed` (#ffdbcc) when selected.

---

## 6. Do's and Don'ts

### Do
*   **Do** use asymmetrical grid alignments (e.g., offsetting a text block by `spacing.12` from its accompanying image) to create an editorial feel.
*   **Do** leverage the `surface` scale to create hierarchy before considering a shadow.
*   **Do** use flat, high-quality vector icons for box types, ensuring they are scaled to `48px` or larger to maintain their "industrial icon" status.

### Don't
*   **Don't** use 1px solid lines to separate list items. Use white space (`spacing.4`) or subtle alternating background tones.
*   **Don't** use pure black (#000000) for text. Always use `on_background` (#1a1c1c) to maintain a premium, slate-like softness.
*   **Don't** use "Standard" orange. Only use the kinetic `primary_container` (#ff6b00) to ensure the brand feels intentional and energetic.
*   **Don't** overcrowd the screen. If the interface feels "efficient," add more white space until it feels "expensive."