# Design System Document

## 1. Overview & Creative North Star: "The Industrial Blueprint"

This design system is engineered to transform a standard industrial utility into a high-end, editorial sales tool. We move away from the "cluttered warehouse" aesthetic toward a **Creative North Star: The Industrial Blueprint.** This concept treats every screen like a master technical drawing—precise, authoritative, yet breathable.

By leveraging intentional asymmetry, sophisticated layering, and an editorial typographic hierarchy, we elevate the box manufacturing process from a commodity to a craft. The interface doesn't just collect data; it builds trust through a "Tool-as-Artifact" philosophy, utilizing subtle glassmorphism and depth to ensure a premium mobile experience for sales teams in the field.

---

## 2. Colors

The palette is anchored in a sophisticated industrial range. We utilize the primary corporate blue and secondary golden-yellow to highlight critical actions and material qualities, while the neutral scale provides the "canvas" for data entry.

### The "No-Line" Rule
To achieve a premium look, **1px solid borders are strictly prohibited for sectioning.** Boundaries must be defined through background color shifts. For example, a content area using `surface-container-low` should sit directly on a `surface` background. This creates a modern, clean separation that feels more integrated than a rigid grid.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. Use the surface-container tiers to create nested depth:
*   **Background:** `surface` (#f9f9fd)
*   **Main Content Blocks:** `surface-container-low` (#f3f3f7)
*   **Active Input Cards:** `surface-container-lowest` (#ffffff)
*   **Elevated Overlays:** `surface-container-high` (#e7e8eb)

### The "Glass & Gradient" Rule
For floating action buttons or primary headers, apply a backdrop-blur (12px–20px) to semi-transparent surface colors. This "frosted glass" effect ensures the industrial heritage of the brand feels modern. Main CTAs should use a subtle linear gradient from `primary` (#005eb2) to `primary_container` (#4192f7) at a 135-degree angle to provide visual "soul" and depth.

---

## 3. Typography

The typography system relies on high-contrast scales to differentiate between "Technical Data" and "User Guidance." 

*   **Display & Headlines (Inter):** These are used sparingly for major section headers (e.g., "Order Summary"). The bold, geometric nature of Inter conveys industrial reliability.
*   **Titles (Inter):** Used for field labels and box types. These should be high-contrast (`on_surface`) to ensure legibility in bright warehouse environments.
*   **Labels (Work Sans):** We use Work Sans for tactical data like measurements and technical specs (e.g., "5mm A/F"). Its slightly wider stance improves readability for quick numerical scanning.
*   **Hierarchy Note:** A `headline-sm` should be used for the main box category, while the dimensions are presented in a `title-lg` weight to signify their primary importance in the manufacturing workflow.

---

## 4. Elevation & Depth

We eschew traditional "shadow-heavy" design for **Tonal Layering.**

### The Layering Principle
Depth is achieved by "stacking" the `surface-container` tiers. A card containing cardboard thickness options should be `surface-container-lowest` placed on a `surface-container-low` background. This creates a soft, natural lift without the visual "noise" of shadows.

### Ambient Shadows
If a floating element (like a "Calculate Price" bar) is required, use extra-diffused shadows:
*   **Blur:** 24px–32px
*   **Opacity:** 4%–6%
*   **Color:** Use a tinted version of `on_surface` (#191c1e) to mimic natural ambient light.

### The "Ghost Border" Fallback
Where a container requires an edge for accessibility (like the "Box Type" selection), use a **Ghost Border**: the `outline-variant` token (#c1c6d5) at 15% opacity. Standard 100% opaque borders are strictly forbidden.

---

## 5. Components

### Buttons
*   **Primary:** Gradient fill (`primary` to `primary_container`), `xl` (12px) roundedness. Used for final price calculations.
*   **Secondary:** Ghost style with a `surface-container-high` background. No border.

### Cardboard Selection (Radio Buttons)
Based on the reference image, cardboard thickness options must be large, touch-friendly tiles. 
*   **State:** Unselected tiles use `surface-container-low`. Selected tiles use a `secondary_container` (#fec700) glow and a `secondary` (#755b00) 2px "Ghost Border" at 40% opacity.
*   **Visuals:** Each tile must include the cross-section icon of the cardboard flute as seen in the reference material.

### Input Fields (Dimensions)
*   **Structure:** Use a `surface-container-lowest` fill. 
*   **Layout:** Group Length (L) x Width (W) x Height (H) in a single horizontal row with large, `title-lg` typography. 
*   **Interaction:** Focus state is indicated by a 2px `primary` underline rather than a full box stroke.

### Lists & Information Tables
*   **Rule:** Forbid divider lines. 
*   **Implementation:** Use the `Spacing Scale (2 or 3)` to create breathing room between price tiers. Alternate background colors between `surface` and `surface-container-lowest` for long tables to guide the eye horizontally.

### Custom Component: The Spec-Sheet Header
A sticky top-bar that utilizes **Glassmorphism**. As the user scrolls through the complex estimation form, the current "Box Type" and "Total Price" remain visible in a semi-transparent blur-over, ensuring the most critical data is always present.

---

## 6. Do's and Don'ts

### Do:
*   **Do** use `Spacing Scale 10` (2.5rem) for vertical separation between major form sections (e.g., between "Dimensions" and "Printing Options").
*   **Do** use `secondary` (#755b00) for "Attention" items like inner-dimension warnings.
*   **Do** utilize the `lg` (8px) and `xl` (12px) roundedness to soften the industrial "tool" vibe.

### Don't:
*   **Don't** use black (#000000) for text. Use `on_surface` (#191c1e) to maintain a premium, softer contrast.
*   **Don't** use standard "drop shadows" on input fields; they should feel embedded in the surface, not hovering over it.
*   **Don't** use more than two font weights on a single screen to maintain the editorial "Blueprint" aesthetic.